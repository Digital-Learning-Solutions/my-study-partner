const sponsors = [
  'Atlassian',
  'Dropbox',
  'Duolingo',
  'GitHub',
  'Microsoft',
  'Netflix',
  'The New York Times',
  'Pearson',
];
import { useState, useEffect, useRef } from 'react';
import bg1 from './assets/canvas.jpg';
import bg2 from './assets/bg.jpg';
function Footer() {
  return (
    <footer className="footer-bar">
      <div className="footer-content">
        <div className="footer-left">
          <span className="footer-logo">AI Learning</span>
          <span className="footer-copy">© {new Date().getFullYear()} AI Driven Personalized Student Learning Platform</span>
        </div>
        <div className="footer-links">
          <a href="#" className="footer-link">About</a>
          <a href="#" className="footer-link">Contact</a>
          <a href="#" className="footer-link">Careers</a>
        </div>
        <div className="footer-social">
          {/* Placeholder for social icons */}
          <a href="#" className="footer-social-icon">🌐</a>
          <a href="#" className="footer-social-icon">🐦</a>
          <a href="#" className="footer-social-icon">💼</a>
        </div>
      </div>
    </footer>
  );
}

import './App.css';
import './styles/header.css';
import './styles/footer.css';
import './styles/slider.css';
import './styles/sponsors.css';
import './styles/courses.css';
import './styles/main.css';
import reactLogo from './assets/react.svg';

function App() {
  // Image slider logic
  const images = [bg1, bg2];
  const [current, setCurrent] = useState(0);
  const [paused, setPaused] = useState(false);
  const intervalRef = useRef();

  useEffect(() => {
    if (!paused) {
      intervalRef.current = setInterval(() => {
        setCurrent((prev) => (prev + 1) % images.length);
      }, 5000);
    }
    return () => clearInterval(intervalRef.current);
  }, [paused, images.length]);

  return (
    <>
      <div className="header-bar">
        <div className="header-logo">
          <img src={reactLogo} alt="Logo" />
        </div>
        <div className="header-center">
          <button className="header-btn">Courses</button>
          <button className="header-btn">Quiz</button>
          <button className="header-btn">Discussions</button>
        </div>
        <div className="header-signin">
          <button className="signin-btn">Sign In</button>
        </div>
      </div>
      <main className="main-content">
        <h1>Welcome to the AI Driven Personalized Student Learning Platform</h1>
        <p>
          Empower your learning journey with personalized courses, interactive quizzes, and engaging discussions. Our platform leverages AI to adapt to your unique needs and help you achieve your academic goals.
        </p>
      </main>

      <div
        className={`image-slider`}
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
      >
        <button
          className="slider-btn slider-btn-left"
          onClick={() => setCurrent((current - 1 + images.length) % images.length)}
          aria-label="Previous image"
        >&#8592;</button>
        <img
          src={images[current]}
          alt="slider"
          className="slider-img"
        />
        <button
          className="slider-btn slider-btn-right"
          onClick={() => setCurrent((current + 1) % images.length)}
          aria-label="Next image"
        >&#8594;</button>
        <div className="slider-dots">
          {images.map((_, idx) => (
            <span
              key={idx}
              className={`slider-dot${current === idx ? ' active' : ''}`}
              onClick={() => setCurrent(idx)}
            >
              &#8226;
            </span>
          ))}
        </div>
      </div>

      {/* Courses Section */}
      <section className="courses-section">
        <h2>Courses</h2>
        <p>Explore a wide range of AI-powered courses tailored to your learning needs.</p>
        <p>Each course adapts to your progress, helping you master concepts efficiently and effectively.</p>
      </section>

      {/* Sponsors Marquee */}
      <div className="sponsors-marquee">
        <div className="sponsors-track">
          {sponsors.concat(sponsors).map((name, idx) => (
            <span className="sponsor-name" key={idx}>{name}</span>
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
}

export default App;
